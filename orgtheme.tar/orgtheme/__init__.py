"""
Organisation theme
"""

__author__ = "Matt Pritchard"
__copyright__ = "Copyright 2018 UK Science and Technology Facilities Council"

__version__ = "0.1"
